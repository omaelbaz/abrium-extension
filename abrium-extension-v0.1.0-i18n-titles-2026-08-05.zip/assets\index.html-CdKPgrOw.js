import{s as X,e as r,i as d,n as f,T as I,b as x,a as tt,m as et,o as at,L as nt,p as st,q as it,c as rt,h as ot,l as lt,d as q,t as l,f as M,g as A,D as ct,r as dt,u as V,v as ut,w as bt,x as ft,y as pt,j as yt,k as gt}from"./templates-CkXz49eJ.js";import{A as O,o as _t,a as ht,b as vt,g as mt,r as wt,c as $t,d as St,e as kt}from"./storage-D3bRYWgj.js";const Et=["all",...O];function Ct(t,e){const n=Et.map(s=>{const i=t.counts[s]??0,u=t.activeFilter===s;return`
      <button
        class="abr-chip"
        type="button"
        role="radio"
        data-action="filter"
        data-filter="${s}"
        aria-checked="${u}"
        aria-pressed="${u}"
        ${s!=="all"&&i===0?"disabled":""}
      >${r(e.t(I[s]))} <span class="abr-chip__count">${r(e.formatCount(i))}</span></button>`}).join("");return`
    <div
      class="abr-chip-row"
      role="radiogroup"
      aria-label="${r(e.t("filter_group_label"))}"
    >${n}</div>`}function Lt(t,e){const n=e.tPlural("artifact_count",t.totalCount,e.formatCount(t.totalCount)),s=t.totalBytes===null?e.t("size_unavailable"):e.formatBytes(t.totalBytes);return r(e.t("stats_summary",[n,s]))}function Dt(t,e){const n=t.status==="loading";return`
    <div class="sp-header__bar">
      ${X(e,{query:t.query,inputId:"sp-search",controlsId:"sp-results"})}
      <button
        class="abr-icon-btn"
        type="button"
        data-action="settings"
        aria-label="${r(e.t("action_settings"))}"
      >${d("settings")}</button>
    </div>

    ${Ct(t,e)}

    <div class="sp-header__stats">
      <p class="abr-caption abr-truncate" id="sp-summary">${n?r(e.t("loading_label")):Lt(t,e)}</p>
      <button
        class="abr-btn abr-btn--ghost abr-btn--sm"
        type="button"
        data-action="toggle-batch"
        aria-pressed="${t.batchMode}"
        ${t.status==="ready"&&t.totalCount>0?"":"disabled"}
      >${r(e.t(t.batchMode?"action_done":"action_select"))}</button>
    </div>`}function Mt(t,e,n,s,i){return`
    <li>
      <article
        class="abr-card"
        role="option"
        tabindex="${i?"0":"-1"}"
        aria-selected="${s}"
        data-id="${r(t.id)}"
      >
        <div class="abr-card__head">
          <span class="sp-check" data-checked="${s}" aria-hidden="true">${s?d("check"):""}</span>
          <div class="abr-card__title abr-card__body">
            <h3 class="abr-subhead abr-truncate">${r(t.title)}</h3>
            ${et(t,e,n)}
          </div>
        </div>
      </article>
    </li>`}function At(t,e,n,s){const i=n.sizes.get(t.id);return n.batchMode?Mt(t,e,i,n.selected.has(t.id),s):tt(t,e,i)}function Bt(){return x(4)}function Ht(t,e){if(t.status==="loading")return Bt();if(t.status==="error")return f({titleKey:"error_title",bodyKey:"error_body",ctx:e,action:{key:"action_retry",name:"retry"},tone:"error"});let n="";return t.showPreviewHint&&(n+=`<li>${f({titleKey:"preview_hint_title",bodyKey:"preview_hint_body",ctx:e,action:{key:"action_dismiss",name:"dismiss-preview-hint",glyph:"close"}})}</li>`),t.totalCount===0?n+f({titleKey:"empty_title",bodyKey:"empty_body",ctx:e}):t.visible.length===0?n+f({titleKey:"no_results_title",bodyKey:"no_results_body",ctx:e,action:{key:"action_reset_filters",name:"reset-filters"}}):(n+=t.visible.map((s,i)=>At(s,e,t,i===0)).join(""),n)}function F(t,e){if(!t.batchMode)return"";const n=t.selected.size,s=e.tPlural("selected_count",n,e.formatCount(n)),i=t.visible.length>0&&t.visible.every(u=>t.selected.has(u.id));return`
    <div class="abr-actionbar" role="group" aria-label="${r(e.t("batch_bar_label"))}">
      <div class="abr-actionbar__row">
        <p class="abr-caption abr-truncate" role="status">${r(s)}</p>
        <span class="abr-toolbar__spacer"></span>
        <button
          class="abr-btn abr-btn--ghost abr-btn--sm"
          type="button"
          data-action="${i?"clear-selection":"select-all"}"
        >${r(e.t(i?"action_clear_selection":"action_select_all"))}</button>
      </div>
      <div class="abr-actionbar__row">
        <button
          class="abr-btn abr-btn--ghost abr-btn--sm"
          type="button"
          data-action="cancel-batch"
        >${r(e.t("action_cancel"))}</button>
        <button
          class="abr-btn abr-btn--secondary abr-btn--sm sp-grow"
          type="button"
          data-action="export"
          ${n===0?"disabled":""}
        >${r(e.t("action_export"))}</button>
        <button
          class="abr-btn abr-btn--primary abr-btn--sm sp-grow"
          type="button"
          data-action="download-zip"
          ${n===0?"disabled":""}
        >${d("archive")}${r(e.t("action_download_zip"))}</button>
      </div>
    </div>`}function Tt(t,e){const n=t.status==="ready"&&t.visible.length>0;return t.batchMode&&n?`role="listbox" aria-multiselectable="true" aria-label="${r(e.t("gallery_label"))}"`:`role="list" aria-label="${r(e.t("gallery_label"))}"`}const qt=512*1024,zt=new Set(["code","markdown","react"]);function Rt(t){return!t||!/^[A-Za-z0-9_-]{1,128}$/.test(t)?null:`https://claude.ai/chat/${t}`}function Pt(t){return t.type!=="html"&&t.type!=="svg"||t.content.trim().length===0?!1:t.content.length<=qt}const z="default-src 'none'; style-src 'unsafe-inline'; img-src data:; font-src data:";function Kt(t,e){const n=["<!doctype html><html><head>",`<meta http-equiv="Content-Security-Policy" content="${z}">`,'<meta charset="utf-8">',"<style>html,body{margin:0;padding:8px;font:13px system-ui,sans-serif;}","img,svg{max-width:100%;height:auto;}</style>","</head><body>",t.content,"</body></html>"].join("");return`
    <iframe
      class="sp-detail__frame"
      sandbox=""
      csp="${r(z)}"
      referrerpolicy="no-referrer"
      loading="lazy"
      title="${r(e.t("detail_preview_label"))}"
      srcdoc="${at(n)}"
    ></iframe>`}function It(t){return`<pre class="abr-code abr-code--full">${r(t.content)}</pre>`}function Vt(t,e){const n=zt.has(t.type),s=n?"detail_source_label":"detail_preview_label";let i;return n?i=t.content.trim().length>0?It(t):f({titleKey:"detail_preview_unavailable_title",bodyKey:"detail_preview_unavailable_body",ctx:e}):Pt(t)?i=Kt(t,e):i=f({titleKey:"detail_preview_unavailable_title",bodyKey:"detail_preview_unavailable_body",ctx:e}),`
    <section class="sp-detail__section">
      <p class="abr-overline">${r(e.t(s))}</p>
      ${i}
    </section>`}function Ot(t,e){const n=t.artifact?.pinned===!0,s=t.status==="ready"&&t.artifact!==null;return`
    <button
      class="abr-icon-btn"
      type="button"
      data-action="back"
      aria-label="${r(e.t("action_back"))}"
    >${d("chevronBack")}</button>
    <span class="abr-toolbar__spacer"></span>
    <button
      class="abr-icon-btn"
      type="button"
      data-action="toggle-pin"
      aria-pressed="${n}"
      aria-label="${r(e.t(n?"action_unpin":"action_pin"))}"
      ${s?"":"disabled"}
    >${d(n?"pinFilled":"pin")}</button>`}function Ft(t,e,n){const s=n.t(I[t.type]),i=e.sizeBytes===null?"":`<span class="abr-bidi-isolate">${r(n.formatBytes(e.sizeBytes))}</span>`,u=Rt(t.conversationId);return`
    <div class="abr-card__meta abr-caption">
      <span class="abr-badge abr-badge--type">${r(s)}</span>
      <span class="abr-truncate">${r(t.filename)}</span>
    </div>
    <div class="abr-card__meta abr-caption">
      ${i}
      <span>${r(n.formatDate(t.createdAt))}</span>
    </div>
    ${u?`<a
             class="sp-link abr-caption"
             href="${r(u)}"
             target="_blank"
             rel="noopener noreferrer"
           >${r(n.t("detail_open_conversation"))}${d("external")}</a>`:""}`}function Nt(t,e){return t.status!=="ready"||!t.artifact?"":t.confirmingDelete?`
      <div class="abr-actionbar" role="group" aria-label="${r(e.t("delete_confirm_title"))}">
        <div class="abr-actionbar__row">
          <p class="abr-caption" role="alert">${r(e.t("delete_confirm_title"))} ${r(e.t("delete_confirm_body"))}</p>
        </div>
        <div class="abr-actionbar__row">
          <button
            class="abr-btn abr-btn--ghost abr-btn--sm sp-grow"
            type="button"
            data-action="cancel-delete"
          >${r(e.t("action_cancel"))}</button>
          <button
            class="abr-btn abr-btn--danger abr-btn--sm sp-grow"
            type="button"
            data-action="confirm-delete"
          >${d("trash")}${r(e.t("action_confirm_delete"))}</button>
        </div>
      </div>`:`
    <div class="abr-actionbar">
      <div class="abr-actionbar__row">
        <button
          class="abr-btn abr-btn--danger abr-btn--sm"
          type="button"
          data-action="request-delete"
        >${d("trash")}${r(e.t("action_delete"))}</button>
        <button
          class="abr-btn abr-btn--primary abr-btn--sm sp-grow"
          type="button"
          data-action="download-one"
        >${d("download")}${r(e.t("action_download"))}</button>
      </div>
    </div>`}function jt(){return`
    <div class="sp-detail__section" aria-hidden="true">
      <div class="abr-skeleton" style="inline-size:80%;block-size:17px"></div>
      <div class="abr-skeleton" style="inline-size:55%"></div>
      <div class="abr-skeleton" style="inline-size:35%"></div>
      <div class="abr-skeleton" style="block-size:160px"></div>
    </div>`}function Ut(t,e){if(t.status==="loading")return jt();if(t.status==="missing")return f({titleKey:"detail_missing_title",bodyKey:"detail_missing_body",ctx:e,action:{key:"action_back",name:"back",glyph:"chevronBack"}});if(t.status==="error"||!t.artifact)return f({titleKey:"detail_error_title",bodyKey:"error_body",ctx:e,action:{key:"action_retry",name:"retry-detail"},tone:"error"});const n=t.artifact;return`
    <h2 class="abr-heading sp-detail__title">${r(n.title)}</h2>
    <div class="sp-detail__meta">${Ft(n,t,e)}</div>
    ${Vt(n,e)}`}function Yt(t,e){return`
    <header class="abr-toolbar sp-detail__bar">
      ${Ot(t,e)}
    </header>
    <main
      class="sp-body sp-detail"
      id="sp-detail"
      aria-label="${r(e.t("detail_label"))}"
      aria-busy="${t.status==="loading"}"
    >${Ut(t,e)}</main>
    ${Nt(t,e)}`}const k={support:"https://www.patreon.com/16547235/join",repository:"https://github.com/omaelbaz/abrium-extension",changelog:"https://abrium.onl/changelog"},Gt={system:"display",light:"sun",dark:"moon"},Wt={system:"theme_system",light:"theme_light",dark:"theme_dark"};function Zt(t,e){return t==="system"?e.t("language_system"):it[t]}function m(t,e,n){return`
    <section class="abr-card abr-card--static sp-settings__group">
      <p class="abr-overline">${r(e.t(t))}</p>
      ${n}
    </section>`}function Jt(t,e){const n=nt.map(s=>`
      <option value="${s}" ${s===t.settings.locale?"selected":""}>${r(Zt(s,e))}</option>`).join("");return m("settings_language",e,`<select
       class="abr-select"
       id="sp-locale"
       data-action="set-locale"
       aria-label="${r(e.t("settings_language"))}"
     >${n}</select>`)}function Qt(t,e){const n=st.map(s=>{const i=s===t.settings.theme;return`
      <button
        class="abr-chip"
        type="button"
        role="radio"
        data-action="set-theme"
        data-theme-choice="${s}"
        aria-checked="${i}"
        aria-pressed="${i}"
      >${d(Gt[s])}${r(e.t(Wt[s]))}</button>`}).join("");return m("settings_theme",e,`<div class="abr-chip-row sp-settings__chips" role="radiogroup"
          aria-label="${r(e.t("settings_theme"))}">${n}</div>`)}function Xt(t,e){const n=e.tPlural("artifact_count",t.totalCount,e.formatCount(t.totalCount)),s=t.totalBytes===null?e.t("size_unavailable"):e.formatBytes(t.totalBytes),i=t.totalCount===0;return m("settings_storage",e,`<p class="abr-body">${r(e.t("stats_summary",[n,s]))}</p>
     <div class="sp-settings__actions">
       <button class="abr-btn abr-btn--secondary abr-btn--sm" type="button" data-action="view-all">
         ${r(e.t("action_view_all"))}
       </button>
       <button
         class="abr-btn abr-btn--secondary abr-btn--sm"
         type="button"
         data-action="export-backup"
         ${i?"disabled":""}
       >${d("download")}${r(e.t("action_export_backup"))}</button>
     </div>`)}function xt(t){return m("settings_privacy",t,`<p class="abr-body">${r(t.t("privacy_note"))}</p>`)}function E(t,e,n,s){const i=s.t(e);return`
    <a
      class="sp-link"
      href="${r(t)}"
      target="_blank"
      rel="noopener noreferrer"
      aria-label="${r(`${i} — ${s.t("link_opens_new_tab")}`)}"
    >${d(n)}${r(i)}${d("external")}</a>`}function te(t,e){return m("settings_about",e,`<p class="abr-caption">${r(e.t("about_version",[t.version]))} &bull; ${r("Built: 2026-08-05 20:11 UTC")}</p>
     <p class="abr-body">${r(e.t("about_open_source"))}</p>
     <div class="sp-settings__links">
       ${E(k.support,"about_support","heart",e)}
       ${E(k.repository,"about_repository","external",e)}
       ${E(k.changelog,"about_changelog","refresh",e)}
     </div>`)}function ee(){return`
    <div class="sp-settings__group" aria-hidden="true">
      <div class="abr-skeleton" style="inline-size:40%;block-size:13px"></div>
      <div class="abr-skeleton" style="block-size:36px"></div>
      <div class="abr-skeleton" style="inline-size:60%"></div>
      <div class="abr-skeleton" style="block-size:36px"></div>
    </div>`}function ae(t,e){return t.status==="loading"?ee():t.status==="error"?f({titleKey:"settings_error_title",bodyKey:"error_body",ctx:e,action:{key:"action_retry",name:"retry-settings"},tone:"error"}):`
    <h2 class="abr-heading">${r(e.t("settings_title"))}</h2>
    ${Jt(t,e)}
    ${Qt(t,e)}
    ${Xt(t,e)}
    ${xt(e)}
    ${te(t,e)}`}function ne(t,e){return`
    <header class="abr-toolbar sp-detail__bar">
      <button
        class="abr-icon-btn"
        type="button"
        data-action="back"
        aria-label="${r(e.t("action_back"))}"
      >${d("chevronBack")}</button>
      <span class="abr-toolbar__spacer"></span>
    </header>
    <main
      class="sp-body sp-settings"
      id="sp-settings"
      aria-label="${r(e.t("settings_label"))}"
      aria-busy="${t.status==="loading"}"
    >${ae(t,e)}</main>`}const se=120,ie=500,g={t:l,tPlural:M,formatDate:gt,formatBytes:yt,formatCount:A},a={view:"gallery",detail:{status:"loading",id:null,artifact:null,sizeBytes:null,confirmingDelete:!1},settingsView:{status:"loading",settings:{...ct}},status:"loading",all:[],usedBytes:0,sizes:new Map,filter:"all",query:"",batchMode:!1,selected:new Set,previewHintActive:!1,previewHintDismissed:!1};function re(t,e){return e===""?!0:t.title.toLowerCase().includes(e)||t.filename.toLowerCase().includes(e)||(t.language??"").toLowerCase().includes(e)}function _(){const t=a.query.trim().toLowerCase(),e=a.all.filter(s=>(a.filter==="all"||s.type===a.filter)&&re(s,t)),n={all:a.all.length};for(const s of O)n[s]=a.all.filter(i=>i.type===s).length;return{status:a.status,visible:e,totalCount:a.all.length,totalBytes:a.usedBytes,sizes:a.sizes,counts:n,activeFilter:a.filter,query:a.query,batchMode:a.batchMode,selected:a.selected,showPreviewHint:a.previewHintActive&&!a.previewHintDismissed}}function y(t){const e=document.querySelector(t);if(!e)throw new Error(`Side panel shell is missing ${t}`);return e}const o={gallery:y("#sp-gallery"),detailRoot:y("#sp-detail-root"),settingsRoot:y("#sp-settings-root"),header:y("#sp-header"),results:y("#sp-results"),actionbar:y("#sp-actionbar"),live:y("#sp-live")};function c(t){o.live.textContent="",window.setTimeout(()=>{o.live.textContent=t},50)}function N(t=_()){o.results.innerHTML=Ht(t,g),o.results.setAttribute("aria-busy",String(t.status==="loading"));for(const s of["role","aria-multiselectable","aria-label"])o.results.removeAttribute(s);const e=document.createElement("div");e.innerHTML=`<i ${Tt(t,g)}></i>`;const n=e.firstElementChild;if(n)for(const s of Array.from(n.attributes))o.results.setAttribute(s.name,s.value);o.actionbar.innerHTML=F(t,g)}function b(){const t=_(),e=document.activeElement,n=e instanceof HTMLInputElement&&e.id==="sp-search",s=n?e.selectionStart:null;if(o.header.innerHTML=Dt(t,g),N(t),n){const i=document.querySelector("#sp-search");i&&(i.focus(),s!==null&&i.setSelectionRange(s,s))}}function oe(){return{status:a.detail.status,artifact:a.detail.artifact,sizeBytes:a.detail.sizeBytes,confirmingDelete:a.detail.confirmingDelete}}function p(){o.detailRoot.innerHTML=Yt(oe(),g)}function w(){o.gallery.hidden=a.view!=="gallery",o.detailRoot.hidden=a.view!=="detail",o.settingsRoot.hidden=a.view!=="settings"}let v=null;async function B(t){a.detail.id=t,a.detail.status="loading",a.detail.artifact=null,a.detail.sizeBytes=null,a.detail.confirmingDelete=!1,p();try{const e=await wt(t);e?(a.detail.artifact=e,a.detail.sizeBytes=await $t(t),a.detail.status="ready"):a.detail.status="missing"}catch(e){a.detail.status="error",console.error("[abrium] Failed to load artifact %s",t,e)}a.detail.id===t&&(p(),le())}function le(){o.detailRoot.querySelector('[data-action="back"]')?.focus()}function ce(t){v=t,a.view="detail",w(),B(t)}function H(){a.view="gallery",a.detail.id=null,a.detail.artifact=null,a.detail.confirmingDelete=!1,w(),o.detailRoot.innerHTML="",((v?o.results.querySelector(`[data-id="${CSS.escape(v)}"]`):null)?.querySelector('[data-action="open"]')??document.querySelector("#sp-search"))?.focus(),v=null}async function de(){const t=a.detail.artifact;if(t)try{const e=await St(t.id,!t.pinned);e?a.detail.artifact=e:(a.detail.status="missing",a.detail.artifact=null),p(),c(l(e?.pinned?"status_pinned":"status_unpinned"))}catch(e){console.error("[abrium] Could not change the pinned state",e),c(l("status_action_failed"))}}async function ue(){const t=a.detail.artifact;if(t)try{await kt(t.id),c(l("status_deleted")),a.all=a.all.filter(e=>e.id!==t.id),a.selected.delete(t.id),v=null,b(),H(),S()}catch(e){console.error("[abrium] Delete failed",e),a.detail.confirmingDelete=!1,p(),c(l("status_action_failed"))}}function be(){return{status:a.settingsView.status,settings:a.settingsView.settings,totalCount:a.all.length,totalBytes:a.usedBytes,version:fe()}}function fe(){try{return chrome.runtime.getManifest().version}catch{return"0.0.0"}}function C(){o.settingsRoot.innerHTML=ne(be(),g)}async function j(){a.settingsView.status="loading",C();try{a.settingsView.settings=await dt(),a.settingsView.status="ready"}catch(t){a.settingsView.status="error",console.error("[abrium] Could not load settings",t)}C(),U()}function U(){o.settingsRoot.querySelector('[data-action="back"]')?.focus()}function pe(){a.view="settings",w(),j()}function L(){a.view="gallery",w(),o.settingsRoot.innerHTML="",document.querySelector('[data-action="settings"]')?.focus()}async function Y(t){const e={...a.settingsView.settings,...t};a.settingsView.settings=e,t.locale!==void 0&&ut(e.locale),t.theme!==void 0&&bt(e.theme);const n=ye(document.activeElement);b(),C(),a.view==="detail"&&p();const s=n?o.settingsRoot.querySelector(n):null;s?s.focus():U();try{await ft(e),c(l("status_settings_saved"))}catch(i){console.error("[abrium] Could not save settings",i),c(l("status_action_failed"))}}function ye(t){if(!(t instanceof HTMLElement))return null;if(t.id==="sp-locale")return"#sp-locale";const e=t.dataset.themeChoice;if(e)return`[data-theme-choice="${CSS.escape(e)}"]`;const n=t.dataset.action;return n?`[data-action="${CSS.escape(n)}"]`:null}async function ge(){try{V(a.all),c(l("status_export_started"))}catch(t){console.error("[abrium] Backup export failed",t),c(l("status_action_failed"))}}async function S(){a.status="loading",b();try{const t=await ht();a.all=t;const[e,n]=await Promise.all([vt(),mt(t.map(i=>i.id))]);a.usedBytes=e,a.sizes=n,a.status="ready";const s=new Set(t.map(i=>i.id));for(const i of a.selected)s.has(i)||a.selected.delete(i)}catch(t){a.status="error",console.error("[abrium] Failed to load artifacts",t)}if(b(),a.status==="ready"){const t=_();c(M("artifact_count",t.visible.length,A(t.visible.length)))}}function _e(t){return a.all.find(e=>e.id===t)}function R(t){return t.closest("[data-id]")?.dataset.id??null}function G(t){a.batchMode=!0,t&&a.selected.add(t),b(),h(0),c(l("batch_mode_entered"))}function D(){a.batchMode=!1,a.selected.clear(),b(),document.querySelector('[data-action="toggle-batch"]')?.focus(),c(l("batch_mode_exited"))}function W(t){a.selected.has(t)?a.selected.delete(t):a.selected.add(t);const e=_(),n=o.results.querySelector(`[data-id="${CSS.escape(t)}"]`);if(n){const s=a.selected.has(t);n.setAttribute("aria-selected",String(s));const i=n.querySelector(".sp-check");i&&(i.dataset.checked=String(s),i.innerHTML=s?d("check"):"")}o.actionbar.innerHTML=F(e,g)}function he(){return a.all.filter(t=>a.selected.has(t.id))}async function ve(t){const e=he();if(e.length!==0)try{t==="export"?(V(e),c(l("status_export_started"))):(await pt(e),c(l("status_zip_started")))}catch(n){console.error("[abrium] Batch action failed",n),c(l("status_action_failed"))}}function me(t){const e=t.target;if(!(e instanceof Element))return;const n=e.closest("[data-action]");if(!n)return;const s=n.dataset.action;switch(s){case"clear-search":{a.query="",b(),document.querySelector("#sp-search")?.focus();return}case"filter":{const i=n.dataset.filter;if(!i||i===a.filter)return;a.filter=i,b();return}case"toggle-batch":{a.batchMode?D():G();return}case"cancel-batch":{D();return}case"select-all":{for(const i of _().visible)a.selected.add(i.id);b();return}case"clear-selection":{a.selected.clear(),b();return}case"export":case"download-zip":{ve(s);return}case"download":{const i=R(n),u=i?_e(i):void 0;if(!u)return;try{q(u),c(l("status_download_started"))}catch(T){console.error("[abrium] Download failed",T),c(l("status_action_failed"))}return}case"open":{const i=R(n);i&&document.dispatchEvent(new CustomEvent("abrium:open-artifact",{detail:{id:i}}));return}case"back":{a.view==="settings"?L():H();return}case"retry-detail":{a.detail.id&&B(a.detail.id);return}case"toggle-pin":{de();return}case"download-one":{const i=a.detail.artifact;if(!i)return;try{q(i),c(l("status_download_started"))}catch(u){console.error("[abrium] Download failed",u),c(l("status_action_failed"))}return}case"request-delete":{a.detail.confirmingDelete=!0,p(),o.detailRoot.querySelector('[data-action="cancel-delete"]')?.focus();return}case"cancel-delete":{a.detail.confirmingDelete=!1,p(),o.detailRoot.querySelector('[data-action="request-delete"]')?.focus();return}case"confirm-delete":{ue();return}case"settings":{document.dispatchEvent(new CustomEvent("abrium:open-settings"));return}case"set-theme":{const i=n.dataset.themeChoice;i&&Y({theme:i});return}case"export-backup":{ge();return}case"view-all":{a.query="",a.filter="all",b(),L();return}case"retry-settings":{j();return}case"retry":{S();return}case"dismiss-preview-hint":{a.previewHintActive=!1,a.previewHintDismissed=!0,b();return}case"reset-filters":{a.query="",a.filter="all",b();return}default:return}}function we(t){const e=t.target;e instanceof HTMLSelectElement&&e.dataset.action==="set-locale"&&Y({locale:e.value})}function $e(t){const e=t.target;!(e instanceof HTMLInputElement)||e.id!=="sp-search"||(window.clearTimeout(P),P=window.setTimeout(()=>{a.query=e.value,N(),Se();const n=_();c(M("artifact_count",n.visible.length,A(n.visible.length)))},se))}let P=0;function Se(){const t=document.querySelector(".abr-field--search");if(!t)return;const e=t.querySelector('[data-action="clear-search"]'),n=a.query.length>0;if(n&&!e){const s=document.createElement("button");s.className="abr-icon-btn abr-icon-btn--sm abr-field__clear",s.type="button",s.dataset.action="clear-search",s.setAttribute("aria-label",l("search_clear")),s.innerHTML=d("close"),t.append(s)}else!n&&e&&e.remove()}function Z(){return Array.from(o.results.querySelectorAll('[role="option"]'))}function h(t){const e=Z();if(e.length===0)return;const n=Math.max(0,Math.min(t,e.length-1));for(const[s,i]of e.entries())i.tabIndex=s===n?0:-1;e[n]?.focus()}function ke(t){if(a.view==="settings"){t.key==="Escape"&&(t.preventDefault(),L());return}if(a.view==="detail"){t.key==="Escape"&&(t.preventDefault(),a.detail.confirmingDelete?(a.detail.confirmingDelete=!1,p(),o.detailRoot.querySelector('[data-action="request-delete"]')?.focus()):H());return}if(t.key==="Escape"&&a.batchMode){t.preventDefault(),D();return}const e=t.target;if(!(e instanceof HTMLElement))return;if(t.key==="/"&&!(e instanceof HTMLInputElement)){t.preventDefault(),document.querySelector("#sp-search")?.focus();return}const n=e.closest('[role="option"]');if(!n)return;const s=Z(),i=s.indexOf(n);switch(t.key){case"ArrowDown":t.preventDefault(),h(i+1);break;case"ArrowUp":t.preventDefault(),h(i-1);break;case"Home":t.preventDefault(),h(0);break;case"End":t.preventDefault(),h(s.length-1);break;case" ":case"Enter":{t.preventDefault();const u=n.dataset.id;u&&W(u);break}}}function Ee(t){if(!a.batchMode)return;const e=t.target;if(!(e instanceof Element))return;const s=e.closest('[role="option"]')?.dataset.id;s&&W(s)}let J=0,$=null;function Q(){window.clearTimeout(J),$&&(delete $.dataset.longpress,$=null)}function Ce(t){if(a.view!=="gallery"||a.batchMode||t.button!==0)return;const e=t.target;if(!(e instanceof Element))return;const n=e.closest(".abr-card[data-id]");n&&($=n,n.dataset.longpress="true",J=window.setTimeout(()=>{const s=n.dataset.id;Q(),s&&G(s)},ie))}function K(){rt(),ot(document),document.addEventListener("click",me),document.addEventListener("change",we),document.addEventListener("input",$e),document.addEventListener("keydown",ke),o.results.addEventListener("click",Ee),o.results.addEventListener("pointerdown",Ce);for(const t of["pointerup","pointercancel","pointermove","scroll"])document.addEventListener(t,Q,{passive:!0});document.addEventListener("abrium:open-settings",()=>{pe()}),document.addEventListener("abrium:open-artifact",t=>{const e=t.detail?.id;typeof e=="string"&&e.length>0&&ce(e)}),chrome.runtime.onMessage.addListener(t=>(t?.type==="capture:preview_hint"&&!a.previewHintDismissed&&!a.previewHintActive&&(a.previewHintActive=!0,b()),!1)),_t(()=>{a.previewHintActive&&(a.previewHintActive=!1),S(),a.view==="detail"&&a.detail.id&&B(a.detail.id)}),w(),lt().then(t=>(a.settingsView.settings=t,b(),S()))}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",K,{once:!0}):K();
//# sourceMappingURL=index.html-CdKPgrOw.js.map
