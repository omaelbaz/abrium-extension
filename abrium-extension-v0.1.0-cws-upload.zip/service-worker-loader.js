import './assets/service-worker.ts-BdY9fb05.js';
